#include<stdio.h>
double logarithm(double x);
void exponent(double x, double y);

double logarithm(double x){
	double sum = 0.0, term =(x-1)/x;
	double deno= 2;
	double temp = term;
	for(int i=0;i<100000;i++){
		sum += temp;
		term *= (x-1)/x;
		temp = term / deno;
		deno++;
	}
	return sum;
}
void exponent(double x, double y){
	double sum=1.0, term;
	double err= 0.0000000001;
	int i=1;

	double a = logarithm(x) * y;
	term=a;
	while( term > err || -term >err){
		sum=sum+term;
		i++;
		term=term*(a/i);
	}
	printf("\nans = %lf",sum);
}
main(){
	double x, y;
	printf("enter x (the base) and y (the power)");
	scanf("%lf %lf", &x , &y);
	exponent(x , y);
}
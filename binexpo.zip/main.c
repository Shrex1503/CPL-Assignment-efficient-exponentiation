/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int binexpo(int a, int b)
{
    int res = 1;
    while(b>0)
    {
        if (b & 1)
        {
            res = res * a;
            
        }
        a = a*a;
    }
    return res;
}

int main()
{
    printf ("%d",binexpo(3, 21));
    

    return 0;
}

